# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Lessons
- ABI calldata for eth_call: build it in Python, never with shell printf padding — a subtly wrong address word silently zeroed an `eligibility()` result (2026-11-02, JIN check). Also remember dynamic-argument head offsets: a single dynamic arg (e.g. `claimFree(string)`) uses offset 0x20, not 0x40; the wrong offset made the dry-run revert with empty data. Always dry-run state-changing calls via eth_call before trusting a view result.
- Updating `telegram-alerts-state.json` processed entries: match the EXACT entry (project name + post_time), never a loose substring — a substring match on "Snake"/"EGGO" overwrote unrelated entries twice (Jolly post 145 on 2026-11-12, EGGO post 294 forwards same day). Print matched projects before writing, and verify count after.
- Copying Keccak constants (RC/RHO/PI) into a new C solver by hand silently truncated the PI table once (2026-11-12, EGGO solver) — always diff the constant tables against the proven solver_day1.c and selftest against Python keccak before mining.
- Sourcify verification: use the v2 API (`https://sourcify.dev/server/v2/contract/56/<addr>`) as the standard — fetching `repo.sourcify.dev/.../metadata.json` often returns 404 even for verified contracts (repo-sync quirk), which falsely flagged OSK as unverified on 2026-11-12. A direct fetch 403 on a project website can likewise be a bot-check, not a dead site — re-check via the live browser before concluding.
- EGGO solver supervision (2026-11-13): the solver dies repeatedly after only ~190–240s even without a VM reboot (suspected runtime reap) — a detached `setsid nohup` launch is NOT enough. The durable fix is the systemd service `eggo-miner.service` + `~/workspace/eggo-miner/eggo_watchdog.sh` (auto-restart from the right nonce, 50M-hash overlap so no nonce range is skipped). The shell runs as root (no `<user>` user exists despite ~ and systemd units have no HOME set — the script must default HOME. The installed unit at /etc/systemd/system/ is ephemeral; the persistent copy lives at ~/workspace/eggo-miner/eggo-miner.service. AMNT jobs must stop/start the SERVICE, not kill the solver process, or the watchdog restarts it within seconds.
- Wallet address handling (2026-11-14, CoinFin check): never hand-type the wallet address in lowercase — one dropped nibble (39 hex chars instead of 40) silently queries a DIFFERENT address and returns plausible 0 balances/mintCounts that contradict the correct reads. Always assert len(address)==42 (0x + 40 hex) after any copy/lowercase, and copy the checksummed address verbatim from the task body or state file.
